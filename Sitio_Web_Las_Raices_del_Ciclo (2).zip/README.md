
# Las Raíces del Ciclo - Sitio Web

Este es el sitio web oficial del libro *Las Raíces del Ciclo*, una novela de fantasía épica creada por Kael Dervan.

## Contenido
- Página de presentación
- Estilo personalizado
- Preparado para GitHub Pages

## Cómo publicarlo
1. Crea una cuenta en [GitHub](https://github.com).
2. Crea un nuevo repositorio.
3. Sube estos archivos.
4. Ve a Settings > Pages y selecciona la rama `main` y carpeta raíz.
5. Espera unos segundos y accede a tu sitio desde el enlace generado.
